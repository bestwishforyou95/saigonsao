-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2014 at 02:17 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `datas_sgs`
--
CREATE DATABASE IF NOT EXISTS `datas_sgs` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `datas_sgs`;

-- --------------------------------------------------------

--
-- Table structure for table `actions`
--

CREATE TABLE IF NOT EXISTS `actions` (
  `idaction` int(11) NOT NULL AUTO_INCREMENT,
  `controllers_id` int(11) NOT NULL,
  `action_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `page_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idaction`),
  KEY `fk_actions_controllers1` (`controllers_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=53 ;

--
-- Dumping data for table `actions`
--

INSERT INTO `actions` (`idaction`, `controllers_id`, `action_name`, `page_name`) VALUES
(3, 1, 'list-group', 'Danh sách nhóm'),
(4, 1, 'rules-group', 'Phân quyền'),
(6, 1, 'list-hotro', 'Hổ trợ trực tuyến'),
(7, 1, 'list-slide', 'Quản lý slide main, slide footer'),
(8, 1, 'list-video', 'Danh sách video'),
(9, 1, 'list-user', 'Quản lý tài khoản'),
(10, 1, 'list-categories-news', 'Danh mục tin'),
(11, 1, 'list-pcates', 'Danh mục sản phẩm'),
(12, 1, 'list-news', 'Danh sách tin'),
(13, 1, 'pages', 'Quản lý trang'),
(14, 1, 'list-prods', 'Quản lý sản phẩm'),
(15, 1, 'allow', 'Cho phép user truy cập trang'),
(16, 1, 'status-user', 'Trang thái user'),
(17, 1, 'status-categories-news', 'Trạng thái danh mục tin'),
(18, 1, 'status-pcates', 'Trạng thái danh mục sản phẩm'),
(19, 1, 'home-pcates', 'Show trang chủ'),
(20, 1, 'qty-pcates', 'Số lượng sản phẩm ở trang chủ'),
(21, 1, 'orderhome-pcates', 'Sắp xếp'),
(22, 1, 'status-news', 'Trạng thái tin'),
(23, 1, 'status-prods', 'Trạng thái sản phẩm'),
(24, 1, 'del-user', 'Xóa tài khoản'),
(25, 1, 'del-categories-news', 'Xóa danh mục tin'),
(26, 1, 'del-pcates', 'Xóa danh mục sản phẩm'),
(27, 1, 'del-news', 'Xóa tin'),
(28, 1, 'insert-user', 'Thêm tài khoản'),
(29, 1, 'insert-slide', 'Thêm slide'),
(30, 1, 'insert-video', 'Thêm video'),
(31, 1, 'insert-hotro', 'Thêm hổ trợ trực tuyến'),
(32, 1, 'insert-categories-news', 'Thêm danh mục tin'),
(33, 1, 'insert-pcates', 'Thêm danh mục sản phẩm'),
(34, 1, 'insert-news', 'Thêm tin'),
(35, 1, 'insert-prods', 'Thêm sản phẩm'),
(36, 1, 'edit-video', 'Sửa video'),
(37, 1, 'edit-hotro', 'Sửa hổ trợ'),
(38, 1, 'edit-slide', 'Sửa slide'),
(39, 1, 'edit-background', 'Sửa nền website'),
(40, 1, 'edit-ads-left', 'Sửa quảng cáo bên trái'),
(41, 1, 'edit-ads-right', 'Sửa quảng cáo phải'),
(42, 1, 'edit-logo', 'Sửa logo'),
(43, 1, 'edit-xahoi', 'Sửa Facebook'),
(44, 1, 'edit-banner', 'Sửa banner'),
(45, 1, 'edit-footer', 'Sửa chân trang'),
(46, 1, 'edit-user', 'Sửa tài khoản'),
(47, 1, 'edit-infor', 'Sửa thông tin tài khoản'),
(48, 1, 'edit-categories-news', 'Sửa danh mục tin'),
(49, 1, 'edit-pcates', 'Sửa danh mục sản phẩm'),
(50, 1, 'edit-news', 'Sửa tin'),
(51, 1, 'edit-page', 'Sửa trang'),
(52, 1, 'edit-prods', 'Sửa sản phẩm');

--
-- Triggers `actions`
--
DROP TRIGGER IF EXISTS `ins_action`;
DELIMITER //
CREATE TRIGGER `ins_action` AFTER INSERT ON `actions`
 FOR EACH ROW BEGIN
        DECLARE done INT DEFAULT FALSE;
        DECLARE id_group INT;
        DECLARE cur CURSOR FOR SELECT `idgroup` FROM `groups`;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
        
        OPEN cur;    
        read_loop: LOOP
            FETCH cur INTO id_group;
            IF done THEN
              LEAVE read_loop;
            END IF;
            INSERT INTO `rules` values(id_group,NEW.idaction,1);
          END LOOP;
        CLOSE cur;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `idarticles` int(11) NOT NULL AUTO_INCREMENT,
  `users_iduser` int(11) NOT NULL,
  `article_title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_alias` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `article_description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_detail` text COLLATE utf8_unicode_ci,
  `article_datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `article_keyword` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_tag` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_status` tinyint(4) NOT NULL DEFAULT '0',
  `article_image` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_thumb` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_type` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `article_view` int(11) DEFAULT NULL,
  PRIMARY KEY (`idarticles`),
  KEY `fk_article_users1` (`users_iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=96 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`idarticles`, `users_iduser`, `article_title`, `article_alias`, `article_description`, `article_detail`, `article_datecreate`, `article_keyword`, `article_tag`, `article_status`, `article_image`, `article_thumb`, `article_type`, `article_view`) VALUES
(68, 1, 'https://www.youtube.com/watch?v=S-KPOxqMazI', '', 'Vũ Điệu hoang dã', NULL, '2014-07-04 08:21:43', NULL, NULL, 1, NULL, NULL, 'Video', NULL),
(69, 1, 'Đề Toán cấu trúc lạ, khó đạt điểm tuyệt đối', 'de-toan-cau-truc-la-kho-dat-diem-tuyet-doi', 'Hàng trăm thí sinh rời phòng thi khi mới 2/3 thời gian và phần lớn không hoàn thành hết bài. Các em cho hay đề không khó nhưng để đạt điểm tuyệt ', '<div class="short_intro txt_666" style="margin: 0px; padding: 0px 0px 10px; color: rgb(68, 68, 68); font-weight: 700; font-size: 14px; line-height: 18px; font-family: arial; float: left;">\r\n	H&agrave;ng trăm th&iacute; sinh rời ph&ograve;ng thi khi mới 2/3 thời gian v&agrave; phần lớn kh&ocirc;ng ho&agrave;n th&agrave;nh hết b&agrave;i. C&aacute;c em cho hay đề kh&ocirc;ng kh&oacute; nhưng để đạt điểm tuyệt đối lại kh&ocirc;ng dễ.</div>\r\n<div class="relative_new" style="margin: 0px; padding: 0px 0px 5px; float: left; color: rgb(0, 0, 0); font-family: arial;">\r\n	<ul class="list_news_dot_3x3_300" style="margin: 0px; padding: 0px; list-style-type: none; float: left; border: none; color: rgb(102, 102, 102);">\r\n		<li style="margin: 0px; padding: 0px 0px 5px 10px; list-style-type: none; background: url(http://st.f3.vnecdn.net/responsive/c/v42/images/graphics/bg_dot_gray_3x3.gif) 0px 6px no-repeat;">\r\n			<a href="http://vnexpress.net/tin-tuc/giao-duc/tuyen-sinh/huong-dan-lam-bai-thi-dai-hoc-mon-toan-3013087.html" style="margin: 0px; padding: 0px; color: rgb(102, 102, 102); text-decoration: none; outline: none; font-weight: 700; line-height: 16px;">Hướng dẫn l&agrave;m b&agrave;i thi đại học m&ocirc;n To&aacute;n</a></li>\r\n	</ul>\r\n</div>\r\n<div id="left_calculator" style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: arial;">\r\n	<div class="fck_detail width_common" style="margin: 0px; padding: 0px 0px 10px; float: left; overflow: hidden; font-size: 14px; color: rgb(51, 51, 51);">\r\n		<p style="margin: 0px 0px 1em; padding: 0px; line-height: 18px; text-align: center;">\r\n			*&nbsp;<a href="http://vnexpress.net/tin-tuc/giao-duc/tuyen-sinh/de-toan-cau-truc-la-kho-dat-diem-tuyet-doi-3013098-p2.html" style="margin: 0px; padding: 0px; color: rgb(0, 79, 139); text-decoration: none; outline: none;" title="Đề thi">Đề thi</a></p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Qu&aacute; nửa thời gian l&agrave;m b&agrave;i, Nguyễn Văn Tu&acirc;n (Bắc Giang) dự thi v&agrave;o ĐH Giao th&ocirc;ng Vận tải (<strong style="margin: 0px; padding: 0px;">H&agrave; Nội</strong>) đ&atilde; rời ph&ograve;ng. Cậu cho biết, cấu tr&uacute;c đề To&aacute;n năm nay kh&aacute;c lạ ở chỗ c&oacute; 9 c&acirc;u, trừ c&acirc;u 1 (2 điểm) c&ograve;n lại đều 1 điểm. Đề kh&ocirc;ng c&oacute; phần chung, phần ri&ecirc;ng, kh&ocirc;ng c&oacute; phần lựa chọn theo chương tr&igrave;nh chuẩn v&agrave; n&acirc;ng cao. Tuy cấu tr&uacute;c đơn giản hơn những năm trước nhưng độ kh&oacute; kh&ocirc;ng hề giảm.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			&quot;Em chỉ l&agrave;m được khoảng 60% b&agrave;i thi, c&ograve;n nhiều &yacute; kh&ocirc;ng l&agrave;m được n&ecirc;n quyết định ra sớm chuẩn bị cho c&aacute;c m&ocirc;n sau&quot;, Tu&acirc;n n&oacute;i.</p>\r\n		<table align="center" border="0" cellpadding="3" cellspacing="0" class="tplCaption" style="margin: 0px auto 10px; padding: 0px; max-width: 100%;">\r\n			<tbody style="margin: 0px; padding: 0px;">\r\n				<tr style="margin: 0px; padding: 0px;">\r\n					<td style="margin: 0px; padding: 0px; line-height: 0;">\r\n						<img alt="thi1-2149-1404446916.jpg" class="img_more" data-natural-="" data-pwidth="480" data-width="500" src="http://m.f29.img.vnecdn.net/2014/07/04/thi1-2149-1404446916.jpg" style="margin: 0px; padding: 0px; border: 0px; font-size: 0px; line-height: 0; max-width: 100%;" /></td>\r\n				</tr>\r\n				<tr style="margin: 0px; padding: 0px;">\r\n					<td style="margin: 0px; padding: 0px; line-height: 0;">\r\n						<p class="Image" style="margin: 0px; padding: 10px; line-height: normal; font-size: 12px; background: rgb(245, 245, 245);">\r\n							Đề thi m&ocirc;n To&aacute;n được th&iacute; sinh đ&aacute;nh gi&aacute; kh&ocirc;ng qu&aacute; kh&oacute;, ngoại trừ c&acirc;u ph&acirc;n loại.Ảnh:&nbsp;<em style="margin: 0px; padding: 0px;">Qu&yacute; Đo&agrave;n.</em></p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Điểm thi ĐH Sư phạm H&agrave; Nội, chưa hết 120 ph&uacute;t đ&atilde; c&oacute; nhiều th&iacute; sinh nộp b&agrave;i. Đa số cho rằng đề thi kh&ocirc;ng l&agrave;m kh&oacute; th&iacute; sinh, nhưng muốn đạt điểm giỏi lại kh&ocirc;ng dễ v&igrave; c&aacute;c c&acirc;u ph&acirc;n loại rất kh&oacute; để lấy điểm. Đ&agrave;o Thị Yến (qu&ecirc; Y&ecirc;n Dũng, Bắc Giang) - một trong những th&iacute; sinh ra khỏi ph&ograve;ng thi đầu ti&ecirc;n cho biết, phần đầu th&igrave; chắc chắn ch&iacute;nh x&aacute;c, nhưng c&acirc;u 9 th&igrave; lại kh&ocirc;ng l&agrave;m được ch&uacute;t n&agrave;o.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			&quot;Cấu tr&uacute;c đề năm nay kh&aacute;c so với những đề m&agrave; em được l&agrave;m quen trước đ&oacute;, nhưng c&aacute;c dạng to&aacute;n th&igrave; kh&ocirc;ng lạ. Em ước chừng được 8-9 điểm&quot;, nữ sinh cho hay.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Tr&aacute;i ngược với Yến, Nguyễn Thị Thanh Hương (Cầu Giấy, H&agrave; Nội) đ&atilde; l&agrave;m được một phần của c&acirc;u 9. Với Hương, c&aacute;c c&acirc;u 6 v&agrave; 8 mới thực sự kh&oacute;, do vậy c&ocirc; chỉ l&agrave;m được 70%. Ngo&agrave;i Đại học Sư phạm, đợt 2 tới Hương sẽ dự thi khối H v&agrave;o Viện đại học mở H&agrave; Nội.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Học viện Bưu ch&iacute;nh Viễn th&ocirc;ng c&oacute; 4-5 th&iacute; sinh ra sớm với gương mặt vui vẻ. Song song với nhận x&eacute;t &ldquo;đề thi dễ&rdquo;, c&aacute;c th&iacute; sinh tỏ ra hết sức ngạc nhi&ecirc;n v&igrave; năm nay Bộ Gi&aacute;o dục kh&ocirc;ng ra theo dạng ph&acirc;n ban tự chọn. &ldquo;Những năm trước, đề lu&ocirc;n c&oacute; hai phần x&aacute;c suất v&agrave; số phức, mỗi c&acirc;u một điểm cho th&iacute; sinh lựa chọn. Tuy nhi&ecirc;n, năm nay hai c&acirc;u đ&oacute; gộp l&agrave;m một. Như thế, ch&uacute;ng em bị thiệt mất 0,5 điểm&rdquo;, Phạm Quang Minh (THPT Nguyễn Văn Huy&ecirc;n, H&agrave; Nội) n&oacute;i.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Theo Minh, đề thi c&oacute; c&aacute;c dạng b&agrave;i cơ bản như khảo s&aacute;t, h&agrave;m số, t&iacute;ch ph&acirc;n, lượng gi&aacute;c, h&igrave;nh học kh&ocirc;ng gian, hệ phương tr&igrave;nh, max-min&hellip;kh&ocirc;ng đ&aacute;nh đố th&iacute; sinh, c&aacute;c con số t&iacute;nh to&aacute;n kh&aacute; đẹp, kh&ocirc;ng qu&aacute; lẻ n&ecirc;n th&iacute; sinh tr&aacute;nh được sự nhầm lẫn.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			&quot;Để lấy 8 điểm, th&iacute; sinh chỉ cần mất 1,5-2 tiếng l&agrave;m b&agrave;i. Tuy nhi&ecirc;n, c&acirc;u bất đẳng thức v&agrave; hệ phương tr&igrave;nh kh&aacute; rắc rối chiếm nhiều thời gian&quot;, Minh cho hay.</p>\r\n		<table align="center" border="0" cellpadding="3" cellspacing="0" class="tplCaption" style="margin: 0px auto 10px; padding: 0px; max-width: 100%;">\r\n			<tbody style="margin: 0px; padding: 0px;">\r\n				<tr style="margin: 0px; padding: 0px;">\r\n					<td style="margin: 0px; padding: 0px; line-height: 0;">\r\n						<img alt="quangminh-2796-1404447065.jpg" data-natural-="" data-pwidth="480" data-width="500" src="http://m.f29.img.vnecdn.net/2014/07/04/quangminh-2796-1404447065.jpg" style="margin: 0px; padding: 0px; border: 0px; font-size: 0px; line-height: 0; max-width: 100%;" /></td>\r\n				</tr>\r\n				<tr style="margin: 0px; padding: 0px;">\r\n					<td style="margin: 0px; padding: 0px; line-height: 0;">\r\n						<p class="Image" style="margin: 0px; padding: 10px; line-height: normal; font-size: 12px; background: rgb(245, 245, 245);">\r\n							Phạm Quanh Minh (&aacute;o đỏ) khi ra khỏi ph&ograve;ng thi. Ảnh:&nbsp;<em style="margin: 0px; padding: 0px;">Quỳnh Trang.</em></p>\r\n					</td>\r\n				</tr>\r\n			</tbody>\r\n		</table>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Điểm thi&nbsp;<strong style="margin: 0px; padding: 0px;">Vinh</strong>&nbsp;sau 2/3 thời gian, l&aacute;c đ&aacute;c th&iacute; sinh rời ph&ograve;ng thi.&nbsp;<span style="margin: 0px; padding: 0px;">Nguyễn Thế Thức (18 tuổi, Đ&ocirc; Lương, Nghệ An) thi v&agrave;o Học viện t&agrave;i ch&iacute;nh cho biết, em l&agrave;m kh&aacute; tốt v&agrave; tự chấm được khoảng 8,5 điểm. Duy nhất c&acirc;u số 9 Thức kh&ocirc;ng l&agrave;m được. &quot;Em từng luyện đề thi đại học c&aacute;c năm trước v&agrave; thấy đề thi năm nay cũng b&igrave;nh thường so với năm ngo&aacute;i&quot;, Thức n&oacute;i.</span></p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Th&iacute; sinh V&otilde; Thị Ng&acirc;n (thị trấn Qu&aacute;n H&agrave;nh) cho biết, đề thi bao h&agrave;m kiến thức rộng, em l&agrave;m được hơn 70%, trong đ&oacute; c&acirc;u 8 v&agrave; c&acirc;u 9 kh&oacute; nhất n&ecirc;n kh&ocirc;ng l&agrave;m kịp.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Hội đồng thi Đại học Kinh tế&nbsp;<strong style="margin: 0px; padding: 0px;">Huế</strong>, đa số th&iacute; sinh cũng nhận định đề thi m&ocirc;n To&aacute;n b&aacute;m s&aacute;t chương tr&igrave;nh s&aacute;ch gi&aacute;o khoa, tuy nhi&ecirc;n, c&acirc;u ph&acirc;n loại rất &iacute;t th&iacute; sinh l&agrave;m được, c&aacute;c em chỉ chắc chắn khoảng 5-6 điểm.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Tại&nbsp;<strong style="margin: 0px; padding: 0px;">Đ&agrave; Nẵng</strong>, điểm thi THPT Phan Đ&igrave;nh Ph&ugrave;ng (quận Thanh Kh&ecirc;), rải r&aacute;c th&iacute; sinh rời ph&ograve;ng thi khi vừa đến thời gian tối thiểu m&agrave; quy chế cho ph&eacute;p. &quot;C&oacute; v&agrave;i c&acirc;u kh&oacute; qu&aacute;, ngồi nghĩ m&atilde;i kh&ocirc;ng ra n&ecirc;n em bỏ ra ngo&agrave;i&quot;, th&iacute; sinh t&ecirc;n H&ugrave;ng n&oacute;i.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Lương Thị Hằng th&igrave; loay hoay với c&aacute;c c&acirc;u giải hệ phương tr&igrave;nh, tọa độ kh&ocirc;ng gian. &quot;Nhiều bạn trong ph&ograve;ng em nộp b&agrave;i sớm, c&ograve;n em cố hết sức cũng chỉ l&agrave;m được 7 c&acirc;u&quot;, c&ocirc; cho hay.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Ở&nbsp;<strong style="margin: 0px; padding: 0px;">TP HCM</strong>,&nbsp;<span style="margin: 0px; padding: 0px;">nhiều th&iacute; sinh dự thi v&agrave;o&nbsp;<span style="margin: 0px; padding: 0px;">ĐH C&ocirc;ng nghiệp&nbsp;</span>đ&atilde; rời ph&ograve;ng khi vừa hết 70% thời gian l&agrave;m b&agrave;i. Đa số th&iacute; sinh cho biết bỏ qua c&acirc;u cuối v&igrave; kh&oacute;.</span></p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			L&agrave; một trong những th&iacute; sinh ra sớm nhất, Đ&agrave;o Thị B&iacute;ch Đ&agrave;o nhận x&eacute;t, đề thi To&aacute;n năm nay kh&aacute; d&agrave;i khi c&oacute; tới 9 c&acirc;u, chưa kể nhiều c&acirc;u c&ograve;n c&oacute; 2-3 y&ecirc;u cầu phải giải quyết. Những c&acirc;u đầu về phần vẽ h&agrave;m thị, lượng gi&aacute;c, số phức hay s&aacute;c xuất... theo Đ&agrave;o, đều ở mức vừa phải kh&aacute; dễ ăn điểm, chỉ cần vững kiến thức s&aacute;ch gi&aacute;o khoa l&agrave; c&oacute; thể giải. Những c&acirc;u cuối mang t&iacute;nh chất n&acirc;ng cao ph&acirc;n loại th&iacute; sinh.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Đặc biệt, phần t&igrave;m gi&aacute; trị lớn nhất ở c&acirc;u cuối đ&atilde; l&agrave;m kh&oacute; hầu hết th&iacute; sinh, Đ&agrave;o cho rằng ngo&agrave;i phương tr&igrave;nh th&iacute; sinh c&ograve;n phải giải trong điều kiện đ&atilde; cho n&ecirc;n kh&ocirc;ng nhiều người giải được.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Tuy vậy, đ&aacute;nh gi&aacute; chung, Đ&agrave;o cho rằng đề kh&ocirc;ng qu&aacute; kh&oacute;, vừa sức để ph&acirc;n loại th&iacute; sinh v&agrave;o ĐH. Đ&agrave;o thi v&agrave;o ng&agrave;nh Kế to&aacute;n trường ĐH C&ocirc;ng nghiệp v&agrave; ước chừng m&igrave;nh được khoảng 6 điểm.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			C&ograve;n Trần Đ&igrave;nh Cường cho rằng đề thi năm nay kh&aacute; kh&oacute;. Cường l&agrave;m chưa hết 2/3 thời gian th&igrave; đ&atilde; nộp b&agrave;i v&igrave; kh&ocirc;ng thể l&agrave;m được những c&acirc;u c&ograve;n lại, nhiều th&iacute; sinh trong ph&ograve;ng Cường cũng nộp b&agrave;i từ rất sớm. Đồng quan điểm với c&aacute;c th&iacute; sinh kh&aacute;c, Cường nhận định c&acirc;u 9 trong đề thi gần như kh&ocirc;ng th&iacute; sinh n&agrave;o ở ph&ograve;ng cậu giải được. &quot;C&oacute; lẽ đ&acirc;y l&agrave; c&acirc;u d&agrave;nh cho những th&iacute; sinh xuất sắc, may m&agrave; c&acirc;u n&agrave;y chỉ chiếm 1 điểm&quot;, Cường chia sẻ.</p>\r\n		<p class="Normal" style="margin: 0px 0px 1em; padding: 0px; line-height: 18px;">\r\n			Ngược lại, rời ph&ograve;ng thi kh&aacute; muộn nhưng một học sinh của trường Marie Curie cho rằng đề thi vừa sức, c&oacute; nhiều c&acirc;u gỡ điểm nhưng cũng c&oacute; c&acirc;u cho th&iacute; sinh giỏi. Nam sinh n&agrave;y cho biết đ&atilde; t&igrave;m ra gi&aacute; trị lớn nhất từ phương tr&igrave;nh của c&acirc;u 9 d&ugrave; mất kh&aacute; nhiều thời gian v&agrave;o c&acirc;u n&agrave;y. &quot;Những c&acirc;u đầu em chỉ mất khoảng một tiếng đồng hồ l&agrave; giải xong, ri&ecirc;ng 3 c&acirc;u cuối, đặc biệt l&agrave; c&acirc;u 9 em phải d&agrave;nh hết khoảng thời gian c&ograve;n lại, giải đi giải lại mới ra&quot;, nam sinh n&agrave;y n&oacute;i v&agrave; cho biết sẽ được &iacute;t nhất l&agrave; 9 điểm ở m&ocirc;n thi đầu ti&ecirc;n.</p>\r\n	</div>\r\n</div>\r\n', '2014-07-04 10:16:11', NULL, NULL, 1, 'img1046453298.jpg', 'img1046453298.jpg', 'Tin tức', 78),
(70, 1, 'http://saigonsao.com.vn/', '', 'Iphone S4 is here', NULL, '2014-07-06 16:28:02', NULL, NULL, 1, 'img5464484082.jpg', 'img5464484082.jpg', 'Slide', 1),
(72, 1, 'mamnon.vn', '', 'Mầm non trẻ thơ', NULL, '2014-07-08 08:13:50', NULL, NULL, 1, 'img5137632050.png', 'img5137632050.png', 'Slide-footer', NULL),
(73, 1, 'hoanganh.vn', '', 'Hoàng Anh', NULL, '2014-07-08 08:31:52', NULL, NULL, 1, 'img7089234306.png', 'img7089234306.png', 'Slide-footer', NULL),
(74, 1, 'aaa', '', 'aaa', NULL, '2014-07-11 07:41:04', NULL, NULL, 1, 'img4089059630.png', 'img4089059630.png', 'Slide-footer', NULL),
(75, 1, 'aaa', '', 'aaa', NULL, '2014-07-11 07:41:12', NULL, NULL, 1, 'img1045544917.png', 'img1045544917.png', 'Slide-footer', NULL),
(76, 1, 'aaa', '', 'aaa', NULL, '2014-07-11 07:43:06', NULL, NULL, 1, 'img6853338124.png', 'img6853338124.png', 'Slide-footer', NULL),
(77, 1, 'Nguyễn Thị Lệ Dung', 'bestwish_foryou95', '0903.341.666', 'bestwishforyou9515', '2014-07-13 09:11:27', NULL, NULL, 1, NULL, NULL, 'hotro', NULL),
(78, 1, 'Võ Thị Thu Linh', 'bestwish_foryou95', '0909.098.677', 'ahgfjt', '2014-07-15 02:19:53', NULL, NULL, 1, NULL, NULL, 'hotro', NULL),
(79, 1, 'Giới thiệu', 'gioi-thieu', '', '<p style="margin: 0px; font-family: Arial, Tahoma, sans-serif; line-height: 20px;">\r\n	<span style="color: rgb(51, 51, 51); font-family: ''times new roman'', times, serif; font-size: 14px; text-align: justify;">- Th&agrave;nh lập v&agrave;o th&aacute;ng 8/2005, <a href="http://saigonsao.com.vn">S&agrave;i G&ograve;n Sao</a></span><span style="font-family: ''times new roman'', times, serif; font-size: 14px; text-align: justify;"><font color="#333333">&nbsp;l&agrave; c&ocirc;ng ty chuy&ecirc;n sản xuất balo, t&uacute;i x&aacute;ch, đồng phục,...ới </font></span></p>\r\n<p style="margin: 0px; font-family: Arial, Tahoma, sans-serif; line-height: 20px;">\r\n	<span style="color: rgb(51, 51, 51); font-family: ''times new roman'', times, serif; font-size: 14px; text-align: justify;">- Voi chứng nhận ti&ecirc;u chuẩn...................</span></p>\r\n<p style="margin: 0px; font-family: Arial, Tahoma, sans-serif; line-height: 20px;">\r\n	&nbsp;</p>\r\n', '2014-07-16 08:49:13', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(80, 1, 'Tuyển dụng', 'tuyendung', '', '<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; text-align: center;">\r\n	<img alt="" src="http://st.web.gate.vn/Images/Editor/TK/AS/thang_4/ctv.jpg" style="box-sizing: border-box; border: 0px; vertical-align: middle; width: 453.359375px; height: 122px;" /></p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n	<span style="box-sizing: border-box; font-size: 18px;"><strong style="box-sizing: border-box;"><span style="box-sizing: border-box; font-family: ''times new roman'', times, serif; text-align: justify;">M&ocirc; tả c&ocirc;ng việc</span></strong></span></p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n	&nbsp;</p>\r\n<h2 style="box-sizing: border-box; font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-weight: 500; line-height: 1.1; margin-top: 20px; margin-bottom: 10px; font-size: 30px; color: rgb(51, 51, 51);">\r\n	<span style="box-sizing: border-box; font-family: ''times new roman'', times, serif;">H&igrave;nh thức ứng tuyển</span></h2>\r\n<ul style="box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n	<li style="box-sizing: border-box; text-align: justify;">\r\n		<span style="box-sizing: border-box; font-family: ''times new roman'', times, serif;"><font color="#333333">C&aacute;c bạn nếu&nbsp;quan t&acirc;m, xin vui l&ograve;ng gửi CV về Email: saigonsao.hcm@gmail.com</font></span></li>\r\n	<li style="color: rgb(51, 51, 51); box-sizing: border-box; text-align: justify;">\r\n		<span style="box-sizing: border-box; font-family: ''times new roman'', times, serif;">Ti&ecirc;u đề Email xin vui l&ograve;ng ghi ti&ecirc;u đề&nbsp;&ldquo;<em style="box-sizing: border-box;">Ứng tuyển vị tr&iacute; CTV viết b&agrave;i S&agrave;i G&ograve;n Sao</em>&rdquo;</span></li>\r\n	<li style="color: rgb(51, 51, 51); box-sizing: border-box; text-align: justify;">\r\n		<span style="box-sizing: border-box; font-family: ''times new roman'', times, serif;">Trong CV ngo&agrave;i c&aacute;c th&ocirc;ng tin c&aacute; nh&acirc;n, th&ocirc;ng tin về tr&igrave;nh độ học vấn, tr&igrave;nh độ chuy&ecirc;n m&ocirc;n... c&aacute;c bạn vui l&ograve;ng gửi về 1 b&agrave;i viết của bạn (tối thiểu 600 chữ) để Ban Quản Trị test khả năng viết l&aacute;ch nh&eacute;.</span></li>\r\n	<li style="color: rgb(51, 51, 51); box-sizing: border-box; text-align: justify;">\r\n		<span style="box-sizing: border-box; font-family: ''times new roman'', times, serif;">Hoặc bạn c&oacute; thể đăng k&yacute; viết b&agrave;i trọn g&oacute;i cho S&agrave;i G&ograve;n Sao ( li&ecirc;n hệ để biết th&ecirc;m chi tiết về mức lương v&agrave; c&ocirc;ng việc ).&nbsp;</span></li>\r\n</ul>\r\n<div style="box-sizing: border-box; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; page-break-after: always;">\r\n	&nbsp;</div>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; text-align: right;">\r\n	<font face="times new roman, times, serif" style="box-sizing: border-box;">C&aacute;m ơn v&agrave; mong được cộng t&aacute;c l&acirc;u d&agrave;i với c&aacute;c bạn hơn ! ^_^</font></p>\r\n<p style="box-sizing: border-box; margin: 0px 0px 10px; color: rgb(51, 51, 51); font-family: ''Helvetica Neue'', Helvetica, Arial, sans-serif; font-size: 14px; line-height: 20px; text-align: right;">\r\n	<strong style="box-sizing: border-box;"><font face="times new roman, times, serif" style="box-sizing: border-box;">Mr.Zorok</font></strong></p>\r\n', '2014-07-16 15:24:36', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(81, 1, 'Hướng dẫn mua hàng', 'huong-dan-mua-hang', 'bmj,,hlk jlhbhg', '<p>\r\n	dhglkj jhftdy yhpl&nbsp;</p>\r\n', '2014-07-17 06:24:27', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(83, 1, 'About us', '', 'jkjojol', NULL, '2014-07-31 14:54:05', NULL, NULL, 1, 'img6560366190.jpg', 'img6560366190.jpg', 'Slide', NULL),
(84, 1, 'http://saigonsao.com.vn/', '', 'a', NULL, '2014-08-01 09:47:30', NULL, NULL, 1, 'img7728274273.jpg', 'img7728274273.jpg', 'Slide', NULL),
(85, 1, 'Giao hàng miễn phí', 'giao-hang-mien-phi', NULL, NULL, '2014-08-04 15:53:01', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(86, 1, 'Chính sách bảo hành', 'chinh-sach-bao-hanh', NULL, NULL, '2014-08-04 15:58:40', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(87, 1, 'Phương thức thanh toán', 'phuong-thuc-thanh-toan', NULL, NULL, '2014-08-04 16:05:15', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(88, 1, 'Phương thức đổi trả hàng', 'phuong-thuc-doi-tra-hang', NULL, NULL, '2014-08-04 16:09:20', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(89, 1, 'Chính sách tích điểm', 'chinh-sach-tich-diem', NULL, NULL, '2014-08-04 16:11:33', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(92, 1, 'Chính sách bán sĩ', 'chinh-sach-ban-si', NULL, NULL, '2014-08-04 16:15:12', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(93, 1, 'Cửa hàng, siêu thị hợp tác', 'cua-hang-sieu-thi-hop-tac', NULL, NULL, '2014-08-04 16:16:58', NULL, NULL, 0, NULL, NULL, 'page', NULL),
(94, 1, 'Võ Thị Thu Linh', 'bestwishforyou95', '0903 431 666', NULL, '2014-08-21 07:27:12', NULL, NULL, 1, NULL, NULL, 'hotrosky', NULL),
(95, 1, 'Nguyễn Thị Lệ Dung', 'bestwishforyou95', '0903.341.666', NULL, '2014-08-21 08:51:37', NULL, NULL, 1, NULL, NULL, 'hotrosky', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `idcategory` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumb` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `alias` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) DEFAULT '1',
  `date_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `sort` int(11) DEFAULT '0',
  `namespace` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`idcategory`, `name`, `image`, `thumb`, `parent_id`, `alias`, `status`, `date_create`, `sort`, `namespace`) VALUES
(18, 'Blogs', NULL, NULL, 0, '', 1, '2014-07-01 08:28:29', NULL, NULL),
(19, 'Test', NULL, NULL, 18, 'test', 1, '2014-07-04 09:25:08', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_has_article`
--

CREATE TABLE IF NOT EXISTS `category_has_article` (
  `categories_idcategory` int(11) NOT NULL,
  `articles_idarticle` int(11) NOT NULL,
  PRIMARY KEY (`categories_idcategory`,`articles_idarticle`),
  KEY `fk_category_has_article_article1` (`articles_idarticle`),
  KEY `fk_category_has_article_category1` (`categories_idcategory`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `category_has_article`
--

INSERT INTO `category_has_article` (`categories_idcategory`, `articles_idarticle`) VALUES
(18, 69),
(19, 69);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE IF NOT EXISTS `config` (
  `idconfig` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `description` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`idconfig`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`idconfig`, `name`, `value`, `description`) VALUES
(1, 'logo', 'img_2014-08-27-09-50-52_3042624005.png', NULL),
(2, 'banner-top', 'img6133424497.jpg', NULL),
(3, 'banner-giua', 'img_2014-08-27-13-12-33_7853702476.gif', NULL),
(4, 'background', 'img_2014-08-26-02-53-10_1792919975.png', 'a:1:{s:6:"status";s:1:"1";}'),
(10, 'footer', '<div style="font-weight:bolder;">\r\n	<h3 style="margin:0px 0px 5px 0px;color:red;font-size:16px;font-weight:bolder;">\r\n		C&Ocirc;NG TY CỔ PHẦN S&Agrave;I G&Ograve;N SAO</h3>\r\n	<div>\r\n		VPGD : 28 Trịnh Lỗi, P.Ph&uacute; Thọ H&ograve;a, Q.T&acirc;n Ph&uacute;, TP.HỒ CH&Iacute; MINH</div>\r\n	<div>\r\n		Xưởng SX : 106/8 Đinh Nghi Xu&acirc;n, P.B&igrave;nh Trị Đ&ocirc;ng, Q. B&igrave;nh T&acirc;n, TP.HỒ CH&Iacute; MINH<br />\r\n		Tell : (08) 22148787 - (08) 22148797 - (08) 22121250 | Fax: (08) 39789687<br />\r\n		Hotline : 0903341666 - 982158634<br />\r\n		Email : saigonsao.hcm@gmail.com - saigonsao_hcm@yahoo.com<br />\r\n		Web :&nbsp;<a href="http://saigonsao.com.vn/" style="text-decoration:none;">www.saigonsao.com.vn</a></div>\r\n</div>\r\n<div class="clearfix">\r\n	&nbsp;</div>\r\n', NULL),
(11, 'xahoi', NULL, 'a:1:{s:8:"facebook";s:15:"176996769176303";}'),
(12, 'ads-left', 'img6224363482.jpg', 'a:2:{s:6:"status";s:1:"0";s:4:"link";s:24:"http://songphapviet.com/";}'),
(13, 'ads-right', 'img5975044577.jpg', 'a:2:{s:6:"status";s:1:"1";s:4:"link";s:22:"https://www.flickr.com";}');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_email` varchar(250) NOT NULL,
  `contact_fullname` varchar(250) NOT NULL,
  `contact_title` varchar(250) NOT NULL,
  `contact_content` text NOT NULL,
  `contact_status` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`contact_id`, `contact_email`, `contact_fullname`, `contact_title`, `contact_content`, `contact_status`) VALUES
(1, 'v2khoi@gmail.com', 'Võ Văn Khôi', 'test', 'test', 0),
(2, 'v2khoi@gmail.com', 'Võ Văn Khôi', '123', '123', 0),
(3, 'bestwish_foryou95@yahoo.com', 'Võ Thị Thu Linh', 'đặt hàng', 'dkajldkjfa;jfdiowa', 0),
(4, 'bestwish_foryou95@yahoo.com', 'Võ Thị Thu Linh', 'đặt hàng', 'dkajldkjfa;jfdiowa', 0);

-- --------------------------------------------------------

--
-- Table structure for table `controllers`
--

CREATE TABLE IF NOT EXISTS `controllers` (
  `idcontroller` int(11) NOT NULL AUTO_INCREMENT,
  `modules_id` int(11) NOT NULL,
  `controller_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idcontroller`),
  KEY `fk_controllers_modules1` (`modules_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `controllers`
--

INSERT INTO `controllers` (`idcontroller`, `modules_id`, `controller_name`) VALUES
(1, 1, 'index');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `idgroup` int(11) NOT NULL AUTO_INCREMENT,
  `namespace` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `image` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(6) COLLATE utf8_unicode_ci DEFAULT '000000',
  PRIMARY KEY (`idgroup`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`idgroup`, `namespace`, `level`, `name`, `description`, `image`, `color`) VALUES
(1, 'admin', 0, 'Admin', 'Quản trị toàn bộ trang', NULL, '000000'),
(2, 'admin', 1, 'Quản lý sản phẩm', 'Quản lý sản phẩm', NULL, '000000'),
(3, 'admin', 2, 'Quản lý tin', 'Quản lý tin', NULL, '000000'),
(4, 'index', 10, 'Khách hàng', NULL, NULL, '000000'),
(5, 'admin', 2, 'Admin SGS', NULL, NULL, '000000');

--
-- Triggers `groups`
--
DROP TRIGGER IF EXISTS `ins_group`;
DELIMITER //
CREATE TRIGGER `ins_group` AFTER INSERT ON `groups`
 FOR EACH ROW BEGIN
        DECLARE done INT DEFAULT FALSE;
        DECLARE id_action INT;
        DECLARE cur CURSOR FOR SELECT `idaction` FROM `actions`;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
        
        OPEN cur;    
        read_loop: LOOP
            FETCH cur INTO id_action;
            IF done THEN
              LEAVE read_loop;
            END IF;
            INSERT INTO `rules` values(NEW.idgroup,id_action,1);
          END LOOP;
        CLOSE cur;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE IF NOT EXISTS `modules` (
  `idmodule` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`idmodule`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`idmodule`, `module_name`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `pcates`
--

CREATE TABLE IF NOT EXISTS `pcates` (
  `pcate_id` int(11) NOT NULL AUTO_INCREMENT,
  `pcate_name` varchar(250) NOT NULL,
  `pcate_alias` varchar(250) NOT NULL,
  `pcate_sort` int(11) NOT NULL DEFAULT '0',
  `pcate_status` tinyint(4) NOT NULL DEFAULT '1',
  `pcate_showhome` tinyint(4) NOT NULL DEFAULT '0',
  `pcate_homeqty` tinyint(4) NOT NULL DEFAULT '8',
  `pcate_orderhome` tinyint(4) NOT NULL DEFAULT '0',
  `pcate_parent` int(11) NOT NULL DEFAULT '0',
  `pcate_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pcate_image` varchar(250) NOT NULL,
  PRIMARY KEY (`pcate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `pcates`
--

INSERT INTO `pcates` (`pcate_id`, `pcate_name`, `pcate_alias`, `pcate_sort`, `pcate_status`, `pcate_showhome`, `pcate_homeqty`, `pcate_orderhome`, `pcate_parent`, `pcate_date`, `pcate_image`) VALUES
(1, 'Sản phẩm quảng cáo', 'san-pham-quang-cao', 0, 1, 1, 4, 2, 0, '2014-07-03 03:27:49', ''),
(14, 'Sản phẩm đồng phục', 'san-pham-dong-phuc', 0, 1, 0, 8, 3, 0, '2014-07-11 08:44:50', ''),
(15, 'Quà thưởng học sinh năm 2014', 'qua-thuong-hoc-sinh-nam-2014', 0, 1, 0, 8, 1, 0, '2014-07-11 08:45:08', ''),
(17, 'Sản phẩm thương hiệu', 'san-pham-thuong-hieu', 0, 1, 0, 8, 4, 0, '2014-07-11 08:46:31', ''),
(18, 'Đồng phục học sinh', 'dong-phuc-hoc-sinh', 0, 1, 0, 8, 0, 14, '2014-07-11 08:47:06', ''),
(19, 'Đồng phục giáo viên', 'dong-phuc-giao-vien', 0, 1, 0, 8, 1, 14, '2014-07-11 08:47:16', ''),
(20, 'Balô - Cặp Trung học', 'balo-cap-trung-hoc', 0, 1, 0, 8, 2, 15, '2014-07-11 08:47:52', ''),
(21, 'Balô - Cặp Tiểu học', 'balo-cap-tieu-hoc', 0, 1, 0, 8, 1, 15, '2014-07-11 08:48:11', ''),
(22, 'Balô Mầm non', 'balo-mam-non-1', 0, 1, 0, 8, 0, 15, '2014-07-11 08:48:24', ''),
(23, 'Bóp viết', 'bop-viet', 0, 1, 0, 8, 6, 15, '2014-07-11 08:48:39', ''),
(24, 'Tập HS', 'tap-hs', 0, 1, 0, 8, 5, 15, '2014-07-11 08:48:55', ''),
(25, 'Áo mưa', 'ao-mua', 0, 1, 0, 8, 4, 15, '2014-07-11 08:49:04', ''),
(26, 'Thú nhồi bông', 'thu-nhoi-bong', 0, 1, 0, 8, 7, 15, '2014-07-11 08:49:19', ''),
(29, 'Túi trống', 'tui-trong', 0, 1, 0, 8, 0, 17, '2014-07-11 08:55:04', ''),
(30, 'Vali cần đẩy du lịch', 'vali-can-day-du-lich', 0, 1, 0, 8, 1, 17, '2014-07-11 08:55:19', ''),
(31, 'Nón', 'non', 0, 1, 0, 8, 3, 15, '2014-08-29 06:02:55', ''),
(32, 'Balô Mầm non', 'balo-mam-non', 0, 1, 1, 4, 0, 1, '2014-08-29 06:12:22', ''),
(33, 'Balô - Cặp Trung học', 'balo-cap-trung-hoc', 0, 1, 0, 4, 1, 1, '2014-08-29 06:13:02', ''),
(34, 'Balô Sinh viên', 'balo-sinh-vien', 0, 1, 0, 4, 2, 1, '2014-08-29 06:15:11', ''),
(35, 'Cặp Công sở', 'cap-cong-so', 0, 1, 0, 4, 3, 1, '2014-08-29 06:15:38', ''),
(36, 'Áo đồng phục', 'ao-dong-phuc', 0, 1, 0, 4, 4, 1, '2014-08-29 06:16:10', ''),
(37, 'Nón', 'non', 0, 1, 0, 4, 5, 1, '2014-08-29 06:16:20', ''),
(38, 'Áo mưa', 'ao-mua', 0, 1, 0, 4, 6, 1, '2014-08-29 06:16:32', ''),
(39, 'Túi vải không dệt', 'tui-vai-khong-det', 0, 1, 0, 4, 7, 1, '2014-08-29 06:16:46', '');

-- --------------------------------------------------------

--
-- Table structure for table `pcate_has_product`
--

CREATE TABLE IF NOT EXISTS `pcate_has_product` (
  `pcates_idpcate` int(11) NOT NULL,
  `products_idproduct` int(11) NOT NULL,
  PRIMARY KEY (`pcates_idpcate`,`products_idproduct`),
  KEY `pcates_idpcate` (`pcates_idpcate`,`products_idproduct`),
  KEY `product_idproduct` (`products_idproduct`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pcate_has_product`
--

INSERT INTO `pcate_has_product` (`pcates_idpcate`, `products_idproduct`) VALUES
(22, 21),
(22, 22),
(22, 23),
(22, 24),
(22, 25),
(22, 26),
(22, 27),
(22, 28),
(22, 29),
(22, 30),
(22, 31),
(22, 32),
(21, 33),
(22, 33),
(21, 34),
(22, 34),
(21, 35),
(22, 35),
(21, 36),
(22, 36),
(21, 37),
(22, 37),
(21, 38),
(22, 38),
(21, 39),
(22, 39),
(21, 40),
(22, 40),
(21, 41),
(22, 41),
(21, 42),
(22, 42),
(21, 43),
(22, 43),
(21, 44),
(22, 44),
(22, 45),
(22, 46),
(22, 47),
(22, 48),
(22, 49),
(22, 50),
(22, 51),
(22, 52),
(22, 53),
(22, 54),
(22, 55),
(22, 56),
(22, 57),
(22, 58),
(22, 59),
(22, 60),
(22, 61),
(22, 62),
(22, 63),
(22, 64),
(22, 65),
(21, 66),
(22, 66),
(21, 67),
(22, 67),
(21, 68),
(22, 68),
(22, 69),
(22, 70),
(22, 71),
(22, 72),
(22, 73),
(22, 74),
(22, 75),
(22, 76),
(22, 77),
(21, 78),
(21, 79),
(21, 80),
(21, 81),
(21, 82),
(21, 83),
(21, 84),
(21, 85),
(21, 86),
(21, 87),
(21, 88),
(21, 89),
(20, 90),
(20, 91),
(20, 92),
(20, 93),
(20, 94),
(20, 95);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_iduser` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `product_alias` varchar(250) NOT NULL,
  `product_price` int(11) NOT NULL DEFAULT '0',
  `product_image` varchar(250) DEFAULT NULL,
  `product_thumb` varchar(250) NOT NULL,
  `product_status` tinyint(4) NOT NULL DEFAULT '0',
  `product_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_description` text NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `product_iduser` (`product_iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_iduser`, `product_name`, `product_alias`, `product_price`, `product_image`, `product_thumb`, `product_status`, `product_date`, `product_description`) VALUES
(21, 1, 'SGS-009D', 'sgs-009d', 0, 'img_2014-08-28-03-14-43_3635871014.jpg', 'img_2014-08-28-03-14-43_3635871014.jpg', 1, '2014-08-28 02:55:07', '<p>\r\n	D&agrave;nh cho c&aacute;c b&eacute; học lớp mầm non</p>\r\n'),
(22, 1, 'SGS-009C', 'sgs-009c', 0, 'img_2014-08-28-05-53-00_3345953506.JPG', 'img_2014-08-28-05-53-00_3345953506.JPG', 1, '2014-08-28 05:53:00', ''),
(23, 1, 'SGS-009B', 'sgs-009b', 0, 'img_2014-08-28-06-17-32_6982735978.jpg', 'img_2014-08-28-06-17-32_6982735978.jpg', 1, '2014-08-28 06:17:32', ''),
(24, 1, 'SGS-009A', 'sgs-009a', 0, 'img_2014-08-28-06-18-11_8081363229.jpg', 'img_2014-08-28-06-18-11_8081363229.jpg', 1, '2014-08-28 06:18:11', ''),
(25, 1, 'SGS-052A', 'sgs-052a', 0, 'img_2014-08-28-06-52-26_8140561870.JPG', 'img_2014-08-28-06-52-26_8140561870.JPG', 1, '2014-08-28 06:52:26', ''),
(26, 1, 'SGS-052B', 'sgs-052b', 0, 'img_2014-08-28-06-52-56_8873598958.JPG', 'img_2014-08-28-06-52-56_8873598958.JPG', 1, '2014-08-28 06:52:56', ''),
(27, 1, 'SGS-052C', 'sgs-052c', 0, 'img_2014-08-28-06-53-39_7673341411.JPG', 'img_2014-08-28-06-53-39_7673341411.JPG', 1, '2014-08-28 06:53:39', ''),
(28, 1, 'SGS-053E', 'sgs-053e', 0, 'img_2014-08-28-06-54-19_4489448272.JPG', 'img_2014-08-28-06-54-19_4489448272.JPG', 1, '2014-08-28 06:54:19', ''),
(29, 1, 'SGS-053A', 'sgs-053a', 0, 'img_2014-08-29-00-37-29_1459057022.jpg', 'img_2014-08-29-00-37-29_1459057022.jpg', 1, '2014-08-29 00:37:29', ''),
(30, 1, 'SGS-053B', 'sgs-053b', 0, 'img_2014-08-29-00-38-30_3274235023.jpg', 'img_2014-08-29-00-38-30_3274235023.jpg', 1, '2014-08-29 00:38:30', ''),
(31, 1, 'SGS-053C', 'sgs-053c', 0, 'img_2014-08-29-00-38-53_7938239659.jpg', 'img_2014-08-29-00-38-53_7938239659.jpg', 1, '2014-08-29 00:38:53', ''),
(32, 1, 'SGS-053D', 'sgs-053d', 0, 'img_2014-08-29-00-39-16_1185004963.jpg', 'img_2014-08-29-00-39-16_1185004963.jpg', 1, '2014-08-29 00:39:16', ''),
(33, 1, 'SGS-063A', 'sgs-063a', 0, 'img_2014-08-29-00-51-37_8139653489.JPG', 'img_2014-08-29-00-51-37_8139653489.JPG', 1, '2014-08-29 00:51:37', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(34, 1, 'SGS-063B', 'sgs-063b', 0, 'img_2014-08-29-00-52-39_1391306824.JPG', 'img_2014-08-29-00-52-39_1391306824.JPG', 1, '2014-08-29 00:52:39', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(35, 1, 'SGS-063C', 'sgs-063c', 0, 'img_2014-08-29-00-54-33_5252079681.JPG', 'img_2014-08-29-00-54-33_5252079681.JPG', 1, '2014-08-29 00:54:33', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(36, 1, 'SGS-063D', 'sgs-063d', 0, 'img_2014-08-29-00-55-30_5615546954.JPG', 'img_2014-08-29-00-55-30_5615546954.JPG', 1, '2014-08-29 00:55:30', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(37, 1, 'SGS-067A', 'sgs-067a', 0, 'img_2014-08-29-00-55-53_4215098698.JPG', 'img_2014-08-29-00-55-53_4215098698.JPG', 1, '2014-08-29 00:55:53', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(38, 1, 'SGS-067B', 'sgs-067b', 0, 'img_2014-08-29-00-56-11_9795834794.jpg', 'img_2014-08-29-00-56-11_9795834794.jpg', 1, '2014-08-29 00:56:11', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(39, 1, 'SGS-067C', 'sgs-067c', 0, 'img_2014-08-29-00-56-23_2240099579.jpg', 'img_2014-08-29-00-56-23_2240099579.jpg', 1, '2014-08-29 00:56:23', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(40, 1, 'SGS-067D', 'sgs-067d', 0, 'img_2014-08-29-00-56-35_4283758665.JPG', 'img_2014-08-29-00-56-35_4283758665.JPG', 1, '2014-08-29 00:56:35', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(41, 1, 'SGS-067E', 'sgs-067e', 0, 'img_2014-08-29-00-56-46_6911628384.JPG', 'img_2014-08-29-00-56-46_6911628384.JPG', 1, '2014-08-29 00:56:46', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(42, 1, 'SGS-068A', 'sgs-068a', 0, 'img_2014-08-29-00-57-13_6618353234.JPG', 'img_2014-08-29-00-57-13_6618353234.JPG', 1, '2014-08-29 00:57:14', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(43, 1, 'SGS-068B', 'sgs-068b', 0, 'img_2014-08-29-00-57-24_8848264159.jpg', 'img_2014-08-29-00-57-24_8848264159.jpg', 1, '2014-08-29 00:57:24', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(44, 1, 'SGS-068C', 'sgs-068c', 0, 'img_2014-08-29-00-57-36_4026197465.JPG', 'img_2014-08-29-00-57-36_4026197465.JPG', 1, '2014-08-29 00:57:36', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(45, 1, 'SGS-078A', 'sgs-078a', 0, 'img_2014-08-29-00-58-05_4041759942.JPG', 'img_2014-08-29-00-58-05_4041759942.JPG', 1, '2014-08-29 00:58:05', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(46, 1, 'SGS-078B', 'sgs-078b', 0, 'img_2014-08-29-00-58-15_5921326223.JPG', 'img_2014-08-29-00-58-15_5921326223.JPG', 1, '2014-08-29 00:58:15', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(47, 1, 'SGS-078C', 'sgs-078c', 0, 'img_2014-08-29-00-58-25_6437387004.JPG', 'img_2014-08-29-00-58-25_6437387004.JPG', 1, '2014-08-29 00:58:25', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(48, 1, 'SGS-079A', 'sgs-079a', 0, 'img_2014-08-29-00-58-50_6405333667.JPG', 'img_2014-08-29-00-58-50_6405333667.JPG', 1, '2014-08-29 00:58:50', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(49, 1, 'SGS-079B', 'sgs-079b', 0, 'img_2014-08-29-01-02-41_8417971325.JPG', 'img_2014-08-29-01-02-41_8417971325.JPG', 1, '2014-08-29 01:02:41', ''),
(50, 1, 'SGS-080A', 'sgs-080a', 0, 'img_2014-08-29-01-03-03_6767273064.JPG', 'img_2014-08-29-01-03-03_6767273064.JPG', 1, '2014-08-29 01:03:03', ''),
(51, 1, 'SGS-080B', 'sgs-080b', 0, 'img_2014-08-29-01-03-15_3303834822.JPG', 'img_2014-08-29-01-03-15_3303834822.JPG', 1, '2014-08-29 01:03:15', ''),
(52, 1, 'SGS-080C', 'sgs-080c', 0, 'img_2014-08-29-01-03-25_7983702584.JPG', 'img_2014-08-29-01-03-25_7983702584.JPG', 1, '2014-08-29 01:03:25', ''),
(53, 1, 'SGS-080D', 'sgs-080d', 0, 'img_2014-08-29-01-03-43_7852784095.JPG', 'img_2014-08-29-01-03-43_7852784095.JPG', 1, '2014-08-29 01:03:43', ''),
(54, 1, 'SGS-081A', 'sgs-081a', 0, 'img_2014-08-29-01-06-20_3218695385.JPG', 'img_2014-08-29-01-06-20_3218695385.JPG', 1, '2014-08-29 01:06:20', ''),
(55, 1, 'SGS-081B', 'sgs-081b', 0, 'img_2014-08-29-01-06-32_4760132934.JPG', 'img_2014-08-29-01-06-32_4760132934.JPG', 1, '2014-08-29 01:06:32', ''),
(56, 1, 'SGS-081C', 'sgs-081c', 0, 'img_2014-08-29-01-06-45_3238045294.JPG', 'img_2014-08-29-01-06-45_3238045294.JPG', 1, '2014-08-29 01:06:45', ''),
(57, 1, 'SGS-081D', 'sgs-081d', 0, 'img_2014-08-29-01-06-55_5158694814.JPG', 'img_2014-08-29-01-06-55_5158694814.JPG', 1, '2014-08-29 01:06:55', ''),
(58, 1, 'SGS-082A', 'sgs-082a', 0, 'img_2014-08-29-01-07-15_4338079273.JPG', 'img_2014-08-29-01-07-15_4338079273.JPG', 1, '2014-08-29 01:07:15', ''),
(59, 1, 'SGS-082B', 'sgs-082b', 0, 'img_2014-08-29-01-07-25_1118785401.JPG', 'img_2014-08-29-01-07-25_1118785401.JPG', 1, '2014-08-29 01:07:25', ''),
(60, 1, 'SGS-082C', 'sgs-082c', 0, 'img_2014-08-29-01-07-36_9988094813.JPG', 'img_2014-08-29-01-07-36_9988094813.JPG', 1, '2014-08-29 01:07:36', ''),
(61, 1, 'SGS-082D', 'sgs-082d', 0, 'img_2014-08-29-01-07-44_8148195045.JPG', 'img_2014-08-29-01-07-44_8148195045.JPG', 1, '2014-08-29 01:07:44', ''),
(62, 1, 'SGS-084A', 'sgs-084a', 0, 'img_2014-08-29-01-08-00_4187934782.JPG', 'img_2014-08-29-01-08-00_4187934782.JPG', 1, '2014-08-29 01:08:00', ''),
(63, 1, 'SGS-084B', 'sgs-084b', 0, 'img_2014-08-29-01-08-11_7692261286.JPG', 'img_2014-08-29-01-08-11_7692261286.JPG', 1, '2014-08-29 01:08:11', ''),
(64, 1, 'SGS-084C', 'sgs-084c', 0, 'img_2014-08-29-01-08-22_8539123750.JPG', 'img_2014-08-29-01-08-22_8539123750.JPG', 1, '2014-08-29 01:08:22', ''),
(65, 1, 'SGS-084D', 'sgs-084d', 0, 'img_2014-08-29-01-08-32_9633781350.JPG', 'img_2014-08-29-01-08-32_9633781350.JPG', 1, '2014-08-29 01:08:32', ''),
(66, 1, 'SGS-085A', 'sgs-085a', 0, 'img_2014-08-29-03-03-03_3448795154.JPG', 'img_2014-08-29-03-03-03_3448795154.JPG', 1, '2014-08-29 03:03:03', ''),
(67, 1, 'SGS-085B', 'sgs-085b-1', 0, 'img_2014-08-29-03-03-16_7837079397.JPG', 'img_2014-08-29-03-03-16_7837079397.JPG', 1, '2014-08-29 03:03:16', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(68, 1, 'SGS-085C', 'sgs-085c', 0, 'img_2014-08-29-03-04-44_2463084898.JPG', 'img_2014-08-29-03-04-44_2463084898.JPG', 1, '2014-08-29 03:04:44', ''),
(69, 1, 'SGS-083A', 'sgs-083a', 0, 'img_2014-08-29-03-05-17_1743783526.JPG', 'img_2014-08-29-03-05-17_1743783526.JPG', 1, '2014-08-29 03:05:17', ''),
(70, 1, 'SGS-083B', 'sgs-083b', 0, 'img_2014-08-29-03-05-27_3113105438.JPG', 'img_2014-08-29-03-05-27_3113105438.JPG', 1, '2014-08-29 03:05:27', ''),
(71, 1, 'SGS-089A', 'sgs-089a', 0, 'img_2014-08-29-03-05-38_3773198170.JPG', 'img_2014-08-29-03-05-38_3773198170.JPG', 1, '2014-08-29 03:05:38', ''),
(72, 1, 'SGS-089B', 'sgs-089b', 0, 'img_2014-08-29-03-05-46_2312934077.JPG', 'img_2014-08-29-03-05-46_2312934077.JPG', 1, '2014-08-29 03:05:46', ''),
(73, 1, 'SGS-092A', 'sgs-092a', 0, 'img_2014-08-29-03-06-08_8317269411.JPG', 'img_2014-08-29-03-06-08_8317269411.JPG', 1, '2014-08-29 03:06:08', ''),
(74, 1, 'SGS-092C', 'sgs-092c', 0, 'img_2014-08-29-03-06-16_1664134375.jpg', 'img_2014-08-29-03-06-16_1664134375.jpg', 1, '2014-08-29 03:06:16', ''),
(75, 1, 'SGS-092D', 'sgs-092d', 0, 'img_2014-08-29-03-06-27_5258794475.JPG', 'img_2014-08-29-03-06-27_5258794475.JPG', 1, '2014-08-29 03:06:27', ''),
(76, 1, 'SGS-092E', 'sgs-092e', 0, 'img_2014-08-29-03-06-33_9955745350.JPG', 'img_2014-08-29-03-06-33_9955745350.JPG', 1, '2014-08-29 03:06:33', ''),
(77, 1, 'SGS-092F', 'sgs-092f', 0, 'img_2014-08-29-03-06-53_5418092776.JPG', 'img_2014-08-29-03-06-53_5418092776.JPG', 1, '2014-08-29 03:06:53', ''),
(78, 1, 'SGS-086A', 'sgs-086a', 0, 'img_2014-08-29-03-16-45_5664377277.jpg', 'img_2014-08-29-03-16-45_5664377277.jpg', 1, '2014-08-29 03:15:03', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(79, 1, 'SGS-086B', 'sgs-086b-2', 0, 'img_2014-08-29-04-36-51_8320616808.jpg', 'img_2014-08-29-04-36-51_8320616808.jpg', 1, '2014-08-29 04:36:12', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(80, 1, 'SGS-086C', 'sgs-086c', 0, 'img_2014-08-29-04-36-27_2449349183.JPG', 'img_2014-08-29-04-36-27_2449349183.JPG', 1, '2014-08-29 04:36:27', ''),
(81, 1, 'SGS-087A', 'sgs-087a', 0, 'img_2014-08-29-04-37-29_3834233573.jpg', 'img_2014-08-29-04-37-29_3834233573.jpg', 1, '2014-08-29 04:37:29', ''),
(82, 1, 'SGS-087B', 'sgs-087b', 0, 'img_2014-08-29-04-37-41_8602958203.jpg', 'img_2014-08-29-04-37-41_8602958203.jpg', 1, '2014-08-29 04:37:41', ''),
(83, 1, 'SGS-087C', 'sgs-087c', 0, 'img_2014-08-29-04-37-48_2890026591.jpg', 'img_2014-08-29-04-37-48_2890026591.jpg', 1, '2014-08-29 04:37:48', ''),
(84, 1, 'SGS-087D', 'sgs-087d', 0, 'img_2014-08-29-04-37-58_6832581487.JPG', 'img_2014-08-29-04-37-58_6832581487.JPG', 1, '2014-08-29 04:37:58', ''),
(85, 1, 'SGS-087E', 'sgs-087e', 0, 'img_2014-08-29-04-38-05_8249519214.jpg', 'img_2014-08-29-04-38-05_8249519214.jpg', 1, '2014-08-29 04:38:05', ''),
(86, 1, 'SGS-087F', 'sgs-087f', 0, 'img_2014-08-29-04-38-12_8776555676.jpg', 'img_2014-08-29-04-38-12_8776555676.jpg', 1, '2014-08-29 04:38:12', ''),
(87, 1, 'SGS-088A', 'sgs-088a', 0, 'img_2014-08-29-04-38-46_9483034605.jpg', 'img_2014-08-29-04-38-46_9483034605.jpg', 1, '2014-08-29 04:38:46', ''),
(88, 1, 'SGS-088B', 'sgs-088b', 0, 'img_2014-08-29-04-38-54_8918765756.JPG', 'img_2014-08-29-04-38-54_8918765756.JPG', 1, '2014-08-29 04:38:54', ''),
(89, 1, 'SGS-088C', 'sgs-088c', 0, 'img_2014-08-29-04-39-03_9598386167.JPG', 'img_2014-08-29-04-39-03_9598386167.JPG', 1, '2014-08-29 04:39:03', ''),
(90, 1, 'SGS-044A', 'sgs-044a-1', 0, 'img_2014-08-29-05-08-10_8827217651.jpg', 'img_2014-08-29-05-08-10_8827217651.jpg', 1, '2014-08-29 04:55:03', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(91, 1, 'SGS-044B', 'sgs-044b', 0, 'img_2014-08-29-05-09-54_9814142415.JPG', 'img_2014-08-29-05-09-54_9814142415.JPG', 1, '2014-08-29 05:08:39', '<p>\r\n	Đang cập nhật...</p>\r\n'),
(92, 1, 'SGS-046', 'sgs-046', 0, 'img_2014-08-29-05-44-53_1298228085.JPG', 'img_2014-08-29-05-44-53_1298228085.JPG', 1, '2014-08-29 05:44:53', ''),
(93, 1, 'SGS-048', 'sgs-048', 0, 'img_2014-08-29-05-45-07_8717341926.JPG', 'img_2014-08-29-05-45-07_8717341926.JPG', 1, '2014-08-29 05:45:07', ''),
(94, 1, 'SGS-051', 'sgs-051', 0, 'img_2014-08-29-05-45-14_9392098755.jpg', 'img_2014-08-29-05-45-14_9392098755.jpg', 1, '2014-08-29 05:45:14', ''),
(95, 1, 'SGS-071', 'sgs-071', 0, 'img_2014-08-29-05-45-25_5583197491.jpg', 'img_2014-08-29-05-45-25_5583197491.jpg', 1, '2014-08-29 05:45:25', '');

-- --------------------------------------------------------

--
-- Table structure for table `rules`
--

CREATE TABLE IF NOT EXISTS `rules` (
  `groups_id` int(11) NOT NULL,
  `actions_id` int(11) NOT NULL,
  `allow` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`groups_id`,`actions_id`),
  KEY `fk_groups_has_actions_actions1` (`actions_id`),
  KEY `fk_groups_has_actions_groups1` (`groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `rules`
--

INSERT INTO `rules` (`groups_id`, `actions_id`, `allow`) VALUES
(1, 3, 1),
(1, 4, 1),
(1, 6, 1),
(1, 7, 1),
(1, 8, 1),
(1, 9, 1),
(1, 10, 1),
(1, 11, 1),
(1, 12, 1),
(1, 13, 1),
(1, 14, 1),
(1, 15, 1),
(1, 16, 1),
(1, 17, 1),
(1, 18, 1),
(1, 19, 1),
(1, 20, 1),
(1, 21, 1),
(1, 22, 1),
(1, 23, 1),
(1, 24, 1),
(1, 25, 1),
(1, 26, 1),
(1, 27, 1),
(1, 28, 1),
(1, 29, 1),
(1, 30, 1),
(1, 31, 1),
(1, 32, 1),
(1, 33, 1),
(1, 34, 1),
(1, 35, 1),
(1, 36, 1),
(1, 37, 1),
(1, 38, 1),
(1, 39, 1),
(1, 40, 1),
(1, 41, 1),
(1, 42, 1),
(1, 43, 1),
(1, 44, 1),
(1, 45, 1),
(1, 46, 1),
(1, 47, 1),
(1, 48, 1),
(1, 49, 1),
(1, 50, 1),
(1, 51, 1),
(1, 52, 1),
(2, 3, 0),
(2, 4, 0),
(2, 6, 0),
(2, 7, 0),
(2, 8, 0),
(2, 9, 0),
(2, 10, 0),
(2, 11, 1),
(2, 12, 0),
(2, 13, 0),
(2, 14, 1),
(2, 15, 0),
(2, 16, 0),
(2, 17, 0),
(2, 18, 1),
(2, 19, 1),
(2, 20, 1),
(2, 21, 1),
(2, 22, 0),
(2, 23, 1),
(2, 24, 0),
(2, 25, 0),
(2, 26, 0),
(2, 27, 0),
(2, 28, 0),
(2, 29, 0),
(2, 30, 0),
(2, 31, 0),
(2, 32, 0),
(2, 33, 0),
(2, 34, 0),
(2, 35, 1),
(2, 36, 0),
(2, 37, 0),
(2, 38, 0),
(2, 39, 0),
(2, 40, 0),
(2, 41, 0),
(2, 42, 0),
(2, 43, 0),
(2, 44, 0),
(2, 45, 0),
(2, 46, 0),
(2, 47, 1),
(2, 48, 0),
(2, 49, 0),
(2, 50, 0),
(2, 51, 0),
(2, 52, 1),
(3, 3, 0),
(3, 4, 0),
(3, 6, 0),
(3, 7, 0),
(3, 8, 0),
(3, 9, 0),
(3, 10, 1),
(3, 11, 0),
(3, 12, 1),
(3, 13, 0),
(3, 14, 0),
(3, 15, 0),
(3, 16, 0),
(3, 17, 0),
(3, 18, 0),
(3, 19, 0),
(3, 20, 0),
(3, 21, 0),
(3, 22, 1),
(3, 23, 0),
(3, 24, 0),
(3, 25, 1),
(3, 26, 0),
(3, 27, 1),
(3, 28, 0),
(3, 29, 0),
(3, 30, 0),
(3, 31, 0),
(3, 32, 0),
(3, 33, 0),
(3, 34, 1),
(3, 35, 0),
(3, 36, 0),
(3, 37, 0),
(3, 38, 0),
(3, 39, 0),
(3, 40, 0),
(3, 41, 0),
(3, 42, 0),
(3, 43, 0),
(3, 44, 0),
(3, 45, 0),
(3, 46, 0),
(3, 47, 1),
(3, 48, 0),
(3, 49, 0),
(3, 50, 1),
(3, 51, 0),
(3, 52, 0),
(4, 3, 0),
(4, 4, 0),
(4, 6, 0),
(4, 7, 0),
(4, 8, 0),
(4, 9, 0),
(4, 10, 0),
(4, 11, 0),
(4, 12, 0),
(4, 13, 0),
(4, 14, 0),
(4, 15, 0),
(4, 16, 0),
(4, 17, 0),
(4, 18, 0),
(4, 19, 0),
(4, 20, 0),
(4, 21, 0),
(4, 22, 0),
(4, 23, 0),
(4, 24, 0),
(4, 25, 0),
(4, 26, 0),
(4, 27, 0),
(4, 28, 0),
(4, 29, 0),
(4, 30, 0),
(4, 31, 0),
(4, 32, 0),
(4, 33, 0),
(4, 34, 0),
(4, 35, 0),
(4, 36, 0),
(4, 37, 0),
(4, 38, 0),
(4, 39, 0),
(4, 40, 0),
(4, 41, 0),
(4, 42, 0),
(4, 43, 0),
(4, 44, 0),
(4, 45, 0),
(4, 46, 0),
(4, 47, 0),
(4, 48, 0),
(4, 49, 0),
(4, 50, 0),
(4, 51, 0),
(4, 52, 0),
(5, 3, 0),
(5, 4, 0),
(5, 6, 1),
(5, 7, 1),
(5, 8, 1),
(5, 9, 1),
(5, 10, 1),
(5, 11, 1),
(5, 12, 1),
(5, 13, 1),
(5, 14, 1),
(5, 15, 0),
(5, 16, 1),
(5, 17, 1),
(5, 18, 1),
(5, 19, 1),
(5, 20, 1),
(5, 21, 1),
(5, 22, 1),
(5, 23, 1),
(5, 24, 1),
(5, 25, 0),
(5, 26, 0),
(5, 27, 1),
(5, 28, 1),
(5, 29, 1),
(5, 30, 1),
(5, 31, 1),
(5, 32, 1),
(5, 33, 1),
(5, 34, 1),
(5, 35, 1),
(5, 36, 1),
(5, 37, 1),
(5, 38, 1),
(5, 39, 1),
(5, 40, 1),
(5, 41, 1),
(5, 42, 1),
(5, 43, 1),
(5, 44, 1),
(5, 45, 1),
(5, 46, 1),
(5, 47, 1),
(5, 48, 1),
(5, 49, 1),
(5, 50, 1),
(5, 51, 1),
(5, 52, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `groups_id` int(11) NOT NULL,
  `username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fullname` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birthday` timestamp NULL DEFAULT NULL,
  `gender` int(11) DEFAULT '0',
  `identitycard` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `yahoo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `skype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `info` text COLLATE utf8_unicode_ci,
  `user_status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`iduser`),
  KEY `fk_users_groups` (`groups_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`iduser`, `groups_id`, `username`, `password`, `email`, `location`, `fullname`, `mobile`, `phone`, `birthday`, `gender`, `identitycard`, `address`, `yahoo`, `skype`, `info`, `user_status`) VALUES
(1, 1, 'admin', '202cb962ac59075b964b07152d234b70', 'bestwishforyou95@gmail.com', NULL, 'Võ Thị Thu Linh', NULL, NULL, '2013-01-19 11:29:20', 0, NULL, NULL, NULL, NULL, NULL, 1),
(7, 4, 'nguyenvana', '202cb962ac59075b964b07152d234b70', 'nguyenvana@gmail.com', NULL, 'Nguyễn Văn A', '0121990777', '0121990777', '1989-06-30 17:00:00', 1, NULL, NULL, 'vana@yahoo.com', 'vana', NULL, 1),
(8, 5, 'saigonsao', '373debac69077a3f279709db49568342', 'saigonsao.hcm@gmail.com', NULL, 'SGS', NULL, NULL, '2014-07-09 17:00:00', 0, NULL, NULL, NULL, NULL, NULL, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `actions`
--
ALTER TABLE `actions`
  ADD CONSTRAINT `fk_actions_controllers1` FOREIGN KEY (`controllers_id`) REFERENCES `controllers` (`idcontroller`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `fk_article_users1` FOREIGN KEY (`users_iduser`) REFERENCES `users` (`iduser`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `category_has_article`
--
ALTER TABLE `category_has_article`
  ADD CONSTRAINT `fk_category_has_article_article1` FOREIGN KEY (`articles_idarticle`) REFERENCES `articles` (`idarticles`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_category_has_article_category1` FOREIGN KEY (`categories_idcategory`) REFERENCES `categories` (`idcategory`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `controllers`
--
ALTER TABLE `controllers`
  ADD CONSTRAINT `fk_controllers_modules1` FOREIGN KEY (`modules_id`) REFERENCES `modules` (`idmodule`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pcate_has_product`
--
ALTER TABLE `pcate_has_product`
  ADD CONSTRAINT `pcate_has_product_ibfk_1` FOREIGN KEY (`pcates_idpcate`) REFERENCES `pcates` (`pcate_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pcate_has_product_ibfk_2` FOREIGN KEY (`products_idproduct`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`product_iduser`) REFERENCES `users` (`iduser`) ON DELETE NO ACTION;

--
-- Constraints for table `rules`
--
ALTER TABLE `rules`
  ADD CONSTRAINT `fk_groups_has_actions_actions1` FOREIGN KEY (`actions_id`) REFERENCES `actions` (`idaction`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_groups_has_actions_groups1` FOREIGN KEY (`groups_id`) REFERENCES `groups` (`idgroup`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_groups` FOREIGN KEY (`groups_id`) REFERENCES `groups` (`idgroup`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
